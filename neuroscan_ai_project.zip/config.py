
APP_NAME = "NeuroScan AI"

CLASS_NAMES = [
    "Non-Demented",
    "Very Mild Demented",
    "Mild Demented",
    "Moderate Demented"
]

STAGE_COLORS = {
    "Non-Demented": "#00C896",
    "Very Mild Demented": "#FFB347",
    "Mild Demented": "#FF6B35",
    "Moderate Demented": "#FF3B5C",
}
