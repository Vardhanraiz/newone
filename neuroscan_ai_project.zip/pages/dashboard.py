
import streamlit as st
from components.kpi_cards import render_kpis

def app():
    st.title("NeuroScan AI Dashboard")
    render_kpis()
    st.info("AI-powered MRI analysis platform for Alzheimer's detection.")
