
import streamlit as st
from components.uploader import upload_mri

def app():
    st.title("MRI Scan Analysis")

    image = upload_mri()

    if image:
        st.image(image,use_container_width=True)

        if st.button("Run AI Analysis"):
            with st.spinner("Running AI model..."):
                st.success("Analysis complete")
                st.write("Prediction: Mild Demented")
                st.write("Confidence: 91%")
