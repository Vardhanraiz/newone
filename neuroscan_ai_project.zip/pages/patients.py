
import streamlit as st
import pandas as pd

def app():
    st.title("Patient Records")

    try:
        df = pd.read_csv("database/patient_records.csv")
        st.dataframe(df)
    except:
        st.warning("No patient database found yet.")
