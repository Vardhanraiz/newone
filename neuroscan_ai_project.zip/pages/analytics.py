
import streamlit as st
import plotly.express as px
import pandas as pd

def app():
    st.title("Analytics Dashboard")

    data = {
        "Stage":["Non-Demented","Very Mild","Mild","Moderate"],
        "Count":[120,80,45,10]
    }

    df = pd.DataFrame(data)

    fig = px.pie(df,names="Stage",values="Count",
                 title="Alzheimer Stage Distribution")

    st.plotly_chart(fig,use_container_width=True)
