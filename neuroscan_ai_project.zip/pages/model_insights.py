
import streamlit as st

def app():
    st.title("Model Performance")

    col1,col2,col3 = st.columns(3)

    col1.metric("Accuracy","91.2%")
    col2.metric("Precision","0.91")
    col3.metric("F1 Score","0.89")
