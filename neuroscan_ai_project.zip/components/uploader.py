
import streamlit as st
from PIL import Image

def upload_mri():
    file = st.file_uploader("Upload MRI Image",type=["jpg","jpeg","png"])

    if file:
        return Image.open(file)
