
import streamlit as st

def render_kpis():
    col1,col2,col3,col4 = st.columns(4)

    col1.metric("Total Scans","124","+12 today")
    col2.metric("Patients","87","+5 new")
    col3.metric("Accuracy","91.2%")
    col4.metric("Speed","<2 sec")
