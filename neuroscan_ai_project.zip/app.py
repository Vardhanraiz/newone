
import streamlit as st
from streamlit_option_menu import option_menu
from pages import dashboard, scan, patients, analytics, model_insights

st.set_page_config(page_title="NeuroScan AI", page_icon="🧠", layout="wide")

# Load CSS
try:
    with open("assets/style.css") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
except:
    pass

with st.sidebar:
    selected = option_menu(
        "NeuroScan AI",
        ["Dashboard","Scan MRI","Patients","Analytics","Model Insights"],
        icons=["speedometer","activity","people","bar-chart","cpu"],
        menu_icon="brain",
        default_index=0
    )

if selected == "Dashboard":
    dashboard.app()

if selected == "Scan MRI":
    scan.app()

if selected == "Patients":
    patients.app()

if selected == "Analytics":
    analytics.app()

if selected == "Model Insights":
    model_insights.app()
